function bellhopnx2d( filename )

% run the BELLHOPNx2D program
%
% usage: bellhop( filename )
% where filename is the environmental file

% Change this to the path where bellhopcuda is saved locally
runbellhopnx2d = 'C:\bellhopcuda\bin\Release\bellhopcudanx2d'

if ( isempty( runbellhopnx2d ) )
   error( 'bellhopnx2d not found in your Matlab path' )
else
   eval( [ '! "' runbellhopnx2d '" ' filename ] );
end