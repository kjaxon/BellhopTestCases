function bellhop3d( filename )

% run the BELLHOP3D program
%
% usage: bellhop( filename )
% where filename is the environmental file

% Change this to the path where bellhopcuda is saved locally
runbellhop3d = 'C:\bellhopcuda\bin\Release\bellhopcuda3d' ;

if ( isempty( runbellhop3d ) )
   error( 'bellhop3d not found in your Matlab path' )
else
   eval( [ '! "' runbellhop3d '" ' filename ] );
end