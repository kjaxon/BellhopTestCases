function bellhop( filename )

% run the BELLHOP program
%
% usage: bellhop( filename )
% where filename is the environmental file

% Change this to the path where bellhopcuda is saved locally
runbellhop = 'C:\bellhopcuda\bin\Release\bellhopcuda.exe' 

if ( isempty( runbellhop ) )
   error( 'bellhop not found in your Matlab path' )
else
   eval( [ '! "' runbellhop '" ' filename ] );
end